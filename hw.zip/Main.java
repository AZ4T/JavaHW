import java.util.*;

public class Main {
    public static void main(String[] args){
        ArrayList<Person> people = new ArrayList<>();

        Student student1 = new Student("Azat", "Bolatbekov", 3.1);
        Student student2 = new Student("Andrew", "Bolatbekov", 2.1);

        Employee employee1 = new Employee("Tom", "Ivanov", "Teacher", 25000);
        Employee employee2 = new Employee("Nursultan", "Imanvekov", "Director", 50000);

        people.add(student1);
        people.add(student2);
        people.add(employee1);
        people.add(employee2);

        Collections.sort(people);
        printData(people);

    }
    public static void printData(Iterable<Person> people){
        for(Person person: people){
            System.out.printf("%s earns %.2f tenge\n", person.toString(), person.getPaymentAmount());
        }
    }
}